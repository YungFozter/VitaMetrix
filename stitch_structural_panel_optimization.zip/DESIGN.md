---
name: Clinical Precision
colors:
  surface: '#f7fafc'
  surface-dim: '#d7dadc'
  surface-bright: '#f7fafc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f6'
  surface-container: '#ebeef0'
  surface-container-high: '#e5e9eb'
  surface-container-highest: '#e0e3e5'
  on-surface: '#181c1e'
  on-surface-variant: '#43474e'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eef1f3'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#455f88'
  primary: '#002045'
  on-primary: '#ffffff'
  primary-container: '#1a365d'
  on-primary-container: '#86a0cd'
  inverse-primary: '#adc7f7'
  secondary: '#0061a5'
  on-secondary: '#ffffff'
  secondary-container: '#66affe'
  on-secondary-container: '#004172'
  tertiary: '#321b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#4f2e00'
  on-tertiary-container: '#c6955e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#adc7f7'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#2d476f'
  secondary-fixed: '#d2e4ff'
  secondary-fixed-dim: '#9fcaff'
  on-secondary-fixed: '#001d37'
  on-secondary-fixed-variant: '#00497e'
  tertiary-fixed: '#ffddba'
  tertiary-fixed-dim: '#f2bc82'
  on-tertiary-fixed: '#2b1700'
  on-tertiary-fixed-variant: '#633f0f'
  background: '#f7fafc'
  on-background: '#181c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.05em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  headline-md-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-padding: 24px
  gutter: 20px
  card-padding: 24px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

The brand personality is authoritative yet empathetic, designed for medical professionals and high-performance athletes. It prioritizes clarity, data integrity, and clinical precision without appearing cold or industrial. The target audience requires instant comprehension of complex physiological data.

This design system utilizes a **Corporate / Modern** style with **Tonal Layering**. It leverages high-quality typography and a restrained color palette to ensure that health metrics remain the focal point. The visual mood is calm, trustworthy, and technologically advanced, echoing the cleanliness of a modern medical facility.

## Colors

The palette is anchored by a deep Navy Primary (`#1A365D`) to convey authority and trust. A vibrant Professional Blue (`#3182CE`) serves as the secondary accent for interactive elements and "low" metric states that aren't necessarily critical.

**Metric State Logic:**
- **Normal:** Deep green indicates health and stability.
- **Low:** Professional blue signals a value below average, used for metrics like muscle mass or hydration where "low" is a technical state.
- **High:** Clinical red used for body fat or visceral risk areas.
- **Warning:** Amber for borderline metrics requiring attention.

The background uses a cool-tinted grey to reduce eye strain during long periods of data analysis, providing a sophisticated backdrop for white elevated cards.

## Typography

This design system uses **Hanken Grotesk** for all primary communication. Its sharp, contemporary geometry provides the "high-tech" feel necessary for medical software while remaining highly legible. 

**JetBrains Mono** is used selectively for technical labels, units of measurement (kg, %, kcal), and raw data points. This creates a clear visual distinction between descriptive text and clinical data.

Headlines for card sections (`headline-sm`) should always be uppercase with slight tracking to act as clear structural anchors for the user's eye. Large numeric displays (e.g., Body Score) utilize `display-lg` for maximum impact.

## Layout & Spacing

The design system follows a **Fluid Grid** model with a consistent 8px baseline rhythm. 

- **Desktop:** 12-column grid. Metric cards typically span 3 or 4 columns depending on complexity.
- **Tablet:** 6-column grid. Cards reflow into a two-column stack.
- **Mobile:** Single column. Cards utilize 100% of the available width with 16px horizontal margins.

Use "Stack" spacing for vertical relationships: `stack-sm` for labels and values, `stack-md` for distinct groups within a card, and `stack-lg` for separating primary content sections.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layers** and **Ambient Shadows**.

1. **Level 0 (Background):** The base page layer (`#EDF2F7`).
2. **Level 1 (Cards):** Pure white surfaces with a soft, highly diffused shadow (Offset: 0px 4px, Blur: 20px, Opacity: 4% Black). 
3. **Level 2 (In-card containers):** Subtle inset backgrounds (`#F8FAFC`) used to group related sub-metrics within a larger card. This replaces the need for heavy borders.
4. **Interactive States:** On hover, cards lift slightly using a more pronounced shadow (Blur: 30px, Opacity: 8% Primary Color) to indicate clickability.

## Shapes

The shape language is **Rounded**, using a 16px (1rem) base radius for all primary containers. This softens the clinical nature of the data, making the interface feel approachable and modern.

- **Primary Cards:** `rounded-xl` (24px) for a soft, premium feel.
- **Internal Elements:** `rounded-md` (8px) for buttons, inputs, and sub-containers.
- **Data Indicators:** Use "Pill" shapes for status badges and chips to maximize contrast with the rectangular grid.

## Components

### Cards
Cards are the primary container. They must include a `headline-sm` title at the top, followed by a light horizontal separator (1px, 5% Primary Color). Padding is generous (24px) to ensure data doesn't feel cramped.

### Metric Indicators
For values like "Muscle Score," use a large numeric value paired with a secondary label. State-specific background tints (e.g., 10% opacity of the state color) can be applied to the background of the value for immediate status recognition.

### Buttons
- **Primary:** Solid `#1A365D` with white text. 8px border radius.
- **Secondary:** Transparent with `#3182CE` border and text.
- **Status Buttons:** Used for "Analyze" or "Save," utilizing the Primary color.

### Progress Bars & Gauges
Linear progress bars should use a 6px height. The "track" is a light grey (`#E2E8F0`), while the "indicator" uses the relevant state color (Normal, High, Low).

### Input Fields
Inputs use the `surface_subtle` background with a 1px border that becomes `#3182CE` on focus. Labels sit 4px above the input in `label-md` JetBrains Mono.